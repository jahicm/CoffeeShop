package ch.swissre.interfaces;

public interface Clonable {

}
